﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MusicLibrary.WebApp.Models;

namespace MusicLibrary.WebApp.Controllers
{
    /// <summary>
    /// Music Controller
    /// </summary>
    public class MusicController : Controller
    { 
        IMusicLibraryClient _client;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="musicLibClient"></param>
        public MusicController(IMusicLibraryClient musicLibClient)
        {
            _client = musicLibClient;
        }
 
        /// <summary>
        /// Load all music library
        /// </summary>
        /// <returns></returns>
        public ActionResult GetMusicList()
        {  
            return View(_client.GetMusicList());
        }
       
        /// <summary>
        /// Search music album
        /// </summary>
        /// <returns></returns>
        public ActionResult SearchMusic()
        {
            return View();
        }

        /// <summary>
        /// Search music album
        /// </summary>
        /// <param name="searchCriteria"></param>
        /// <returns></returns>
        public ActionResult SearchMusicList(MusicLibrarySearchCriteria searchCriteria)
        {
            var musicLibrarySearchResult = _client.GetMusicListWithSearchCriteria(searchCriteria);
            return View(musicLibrarySearchResult);
        }

        /// <summary>
        /// Add composing details
        /// </summary>
        /// <returns></returns>
        public ActionResult InsertMusicLibrary()
        {
            return View();
        }
    }
}