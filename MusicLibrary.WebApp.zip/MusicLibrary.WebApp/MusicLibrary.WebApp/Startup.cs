﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(MusicLibrary.WebApp.Startup))]
namespace MusicLibrary.WebApp
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
