﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MusicLibrary.WebApp.Models
{
    /// <summary>
    /// Music Library Search Criteria
    /// Created By Parthiban Rajendran on 25 Dec 2019
    /// </summary>
    public class MusicLibrarySearchCriteria
    {
        /// <summary>
        /// Composer Name
        /// </summary>
        [Display(Name = "Composer Name")]
        public string ComposerName { get; set; }

        /// <summary>
        /// Album Name
        /// </summary>
        [Display(Name = "Album Name")]
        public string AlbumName { get; set; }

        /// <summary>
        /// Title Name
        /// </summary>
        [Display(Name = "Title Name")]
        public string TitleName { get; set; }
    }
}