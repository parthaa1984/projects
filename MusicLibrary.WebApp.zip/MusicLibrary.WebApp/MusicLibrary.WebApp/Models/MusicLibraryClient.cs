﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using MusicLibrary.WebApp.Models;

namespace MusicLibrary.WebApp.Models
{
    /// <summary>
    /// Music Library Clinet
    /// </summary>
    public class MusicLibraryClient : IMusicLibraryClient
    {
        private string Base_URL = "http://localhost:64860/api/";

        /// <summary>
        /// Load all music library
        /// </summary>
        /// <returns></returns>
        public IEnumerable<MusicLibrary> GetMusicList()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("musiclibraries").Result;

                if (response.IsSuccessStatusCode)                    
                    return response.Content.ReadAsAsync<IEnumerable<Models.MusicLibrary>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Search music album
        /// </summary>
        /// <param name="searchCriteria"></param>
        /// <returns></returns>
        public IEnumerable<MusicLibrary> GetMusicListWithSearchCriteria(MusicLibrarySearchCriteria searchCriteria)
        {
            IEnumerable<MusicLibrary> returnValue = null;
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                 
                var postLibrary = client.PostAsJsonAsync<MusicLibrarySearchCriteria>("searchmusiclibraries", searchCriteria);
                postLibrary.Wait();
 
                var result = postLibrary.Result;
                if (result.IsSuccessStatusCode)
                {

                    var readTask = result.Content.ReadAsAsync<IEnumerable<MusicLibrary>>();
                    readTask.Wait();

                    returnValue = readTask.Result; 
                }
            }
            catch
            {
                returnValue = null;
            }
            return returnValue;
        }

        /// <summary>
        /// Add composing details
        /// </summary>
        /// <param name="musicdata"></param>
        /// <returns></returns>
        public int AddMusicLibrary(MusicLibrary musicdata)
        {
            var returnValue = -1;
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json")); 
                var postLibrary =  client.PostAsJsonAsync<MusicLibrary>("addmusic", musicdata);
                postLibrary.Wait();

                var result = postLibrary.Result;
                if (result.IsSuccessStatusCode)
                {

                    var readTask = result.Content.ReadAsAsync<int>();
                    readTask.Wait();

                    returnValue = readTask.Result; 
                }
           
                return returnValue;

            }
            catch
            {
                return returnValue;
            }
        }
    }
}