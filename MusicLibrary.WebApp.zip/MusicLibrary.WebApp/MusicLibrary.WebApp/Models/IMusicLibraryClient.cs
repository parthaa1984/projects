﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicLibrary.WebApp.Models
{
    /// <summary>
    /// Interface Music Library
    /// </summary>
    public interface IMusicLibraryClient
    {
        IEnumerable<Models.MusicLibrary> GetMusicList();
        IEnumerable<MusicLibrary> GetMusicListWithSearchCriteria(MusicLibrarySearchCriteria searchCriteria);
    }
}
