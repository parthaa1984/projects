﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MusicLibrary.WebApp.Models
{
    /// <summary>
    /// Music Library Entity
    /// </summary>
    public class MusicLibrary
    {
        public int MusicLibraryId { get; set; }
        [Required]
        [Display(Name ="Title Name")]
        public string TitleName { get; set; }
        [Required]
        [Display(Name = "Album Name")]
        public string AlbumName { get; set; }
        [Required]
        [Display(Name = "Composer Name")]
        public string ComposerName { get; set; }
        [Required]
        [Display(Name = "Released Date (dd/MM/yyyy)")]
        [MaxLength(length:10)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime ReleasedDate { get; set; }
        [Required]
        [Display(Name = "Artist Name")]
        public string ArtistName { get; set; }
    }
}