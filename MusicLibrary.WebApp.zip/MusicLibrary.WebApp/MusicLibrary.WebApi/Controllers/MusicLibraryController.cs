﻿using System.Linq;
using System.Web.Http;
using MusicLibrary.WebApi.Models;
using System.Web.Http.Description;
using System.Collections.Generic;
using System.Net.Http;
using System.Net;


namespace MusicLibrary.WebApi.Controllers
{
    /// <summary>
    /// Music Library API Controller
    /// </summary>
    public class MusicLibraryController : ApiController
    { 
        [Route("api/musiclibraries")]
        public HttpResponseMessage GetAllMusicLibraries()
        {
            var musiclibraries = MusicLibraryRepository.GetAllMusicLibrary();
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, musiclibraries);
            return response;
        }

        
        [Route("api/searchmusiclibraries")]
        public HttpResponseMessage POSTSearchMusicLibraries(MusicLibrarySearchCriteria searchCriteria)
        {
            var musiclibraries = MusicLibraryRepository.SearchMusicLibrary(searchCriteria);
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, musiclibraries);
            return response;
        }

        [Route("api/addmusic")]
        public HttpResponseMessage PostAddMusicLibrary(Models.MusicLibrary music)
        {
            var musicLibraryId =  MusicLibraryRepository.InsertMusic(music);
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, musicLibraryId);
            return response;
        } 
    }
}