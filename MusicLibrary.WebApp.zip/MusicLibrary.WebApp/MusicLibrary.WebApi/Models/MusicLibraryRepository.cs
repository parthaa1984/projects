﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MusicLibrary.WebApi.Models
{
    /// <summary>
    /// Music Library Repository
    /// </summary>
    public sealed class MusicLibraryRepository
    {
        private static MusicLibraryDataEntities dataContext = new MusicLibraryDataEntities(); 
        private MusicLibraryRepository()
        { 
        }
        /// <summary>
        /// Load All Album library from In-Memory database
        /// </summary>
        /// <returns></returns>
        public static List<MusicLibrary> GetAllMusicLibrary()
        {
            var query = from music in dataContext.MusicLibraries select music;

            return query.ToList();
        }

        /// <summary>
        /// Insert Music Album
        /// </summary>
        /// <param name="music"></param>
        /// <returns></returns>
        public static int InsertMusic(MusicLibrary music)
        {
            dataContext.MusicLibraries.Add(music);
            dataContext.SaveChanges();
            return music.MusicLibraryId;
        }

        /// <summary>
        /// Search Music Album based on the given search criteria
        /// </summary>
        /// <param name="searchCriteria"></param>
        /// <returns></returns>
        public static List<MusicLibrary> SearchMusicLibrary(MusicLibrarySearchCriteria searchCriteria)
        {
            List<MusicLibrary> musicList = null;

            if(searchCriteria!=null)
            {
                musicList = (from n in dataContext.MusicLibraries
                             where n.AlbumName.Contains(searchCriteria.AlbumName)
                             || n.ComposerName.Contains(searchCriteria.ComposerName)
                             || n.TitleName.Contains(searchCriteria.TitleName)
                             orderby n.TitleName ascending
                             select n).ToList();
            }
            return musicList;
        }
    }
}