﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MusicLibrary.WebApi.Models
{
    /// <summary>
    /// Music Library Search Criteria
    /// Created By Parthiban Rajendran on 25 Dec 2019
    /// </summary>
    public class MusicLibrarySearchCriteria
    {
        /// <summary>
        /// Composer Name
        /// </summary>
        public string ComposerName { get; set; }

        /// <summary>
        /// Album Name
        /// </summary>
        public string AlbumName { get; set; }

        /// <summary>
        /// Title Name
        /// </summary>
        public string TitleName { get; set; }
    }
}